from semantic_kernel.kernel import Kernel


class MicroservicesReview:
    def __init__(self, kernel: Kernel):
        self.kernel = kernel

    async def review(self, architecture_desc: str) -> str:
        """Generate a detailed review report for the given microservices architecture."""
        prompt = f"""
        Conduct a comprehensive review of the given microservices architecture. Focus on these aspects:

        - **Inter-Service Communication:** Analyze communication protocols (e.g., REST, gRPC, messaging systems) to ensure efficient data exchange, evaluate latency, serialization/deserialization overhead, and potential bottlenecks.
        - **Load Balancing:** Assess load balancing mechanisms, including configurations for dynamic scaling under varying workloads, and identify any limitations or inefficiencies.
        - **Fault Tolerance:** Review mechanisms for handling failures, such as retry policies, circuit breakers, and failover strategies. Verify the effectiveness of service degradation or fallback options during outages.
        - **Service Dependencies:** Map and evaluate dependencies among services to identify potential risks of cascading failures. Analyze service startup sequences, health checks, and dependency management.

        Architecture Description:
        {architecture_desc}

        Please provide a detailed review report with key findings and recommendations.
        Only return the content of the report, without additional metadata or formatting.
        """

        response = await self.kernel.invoke_prompt(prompt)
        return str(response)
